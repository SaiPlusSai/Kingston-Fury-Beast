const dynamoDbService = require('../aws/dynamodb.service');
const { useInMemoryStore } = require('../config/database');

const getDataAdapter = () => {
  if (useInMemoryStore) {
    return require('./inMemoryStore');
  }
  return { dynamoDbService };
};

module.exports = {
  dynamoDbService,
  getDataAdapter,
  useInMemoryStore,
};

const rateLimit = require('express-rate-limit');
const { env } = require('../config/env');

const apiRateLimiter = rateLimit({
  windowMs: env.rateLimit.windowMs,
  max: env.rateLimit.maxRequests,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many requests, please try again later',
    data: null,
    errors: null,
  },
});

const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: {
    success: false,
    message: 'Too many authentication attempts',
    data: null,
    errors: null,
  },
});

module.exports = {
  apiRateLimiter,
  authRateLimiter,
};

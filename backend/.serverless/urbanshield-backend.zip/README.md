# UrbanShield Backend API

Production-ready REST API for the UrbanShield smart-city emergency reporting platform.

## Tech Stack

- Node.js + Express.js (JavaScript)
- JWT authentication with role-based access control
- AWS SDK v3 (Cognito, S3, DynamoDB, SNS, Location Service)
- Joi validation, Helmet, CORS, rate limiting
- Swagger/OpenAPI documentation
- Lambda + API Gateway ready via `serverless-http`

## Quick Start

```bash
cd backend_urbanshield
cp .env.example .env
npm install
npm run dev
```

API: `http://localhost:4000/api`  
Docs: `http://localhost:4000/api-docs`

### Development credentials (in-memory store)

| Role    | Email                   | Password    |
|---------|-------------------------|-------------|
| Admin   | admin@urbanshield.com   | Urban123!   |
| Citizen | citizen@urbanshield.com | Urban123!   |

## Project Structure

```
src/
├── app.js              # Express application
├── server.js           # HTTP server entry
├── lambda.js           # AWS Lambda handler
├── config/             # Environment & AWS config
├── constants/          # Roles, statuses, categories
├── controllers/        # HTTP request handlers
├── routes/             # REST route definitions
├── middlewares/        # Auth, validation, errors
├── services/           # Business logic
├── repositories/       # Data access (DynamoDB)
├── models/             # Entity shapes
├── validators/         # Joi schemas
├── aws/                # AWS service abstractions
├── database/           # DynamoDB & in-memory store
├── errors/             # Custom error classes
├── utils/              # Helpers (JWT, geo, pagination)
└── docs/               # OpenAPI specification
```

## API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register citizen |
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/refresh` | Refresh tokens |
| POST | `/api/auth/logout` | Logout (protected) |
| POST | `/api/auth/forgot-password` | Request reset |
| POST | `/api/auth/reset-password` | Reset password |
| GET | `/api/auth/me` | Current user profile |

### Reports
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/reports` | List reports (paginated) |
| POST | `/api/reports` | Create report |
| GET | `/api/reports/:id` | Report details |
| PATCH | `/api/reports/:id/status` | Update status (admin) |
| POST | `/api/reports/:id/resolve` | Resolve incident (admin) |
| GET | `/api/reports/nearby` | Nearby incidents |
| GET | `/api/reports/analytics` | Analytics (admin) |

### Uploads
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/uploads/presigned-url` | S3 presigned upload URL |

### Notifications
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/notifications` | List user notifications |
| PATCH | `/api/notifications/:id/read` | Mark as read |
| PATCH | `/api/notifications/read-all` | Mark all as read |

### Location
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/location/search` | Place search (AWS Location) |
| GET | `/api/location/markers` | Map markers |
| GET | `/api/location/radius` | Radius search |
| GET | `/api/location/heatmap` | Heatmap data |

### Admin
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/dashboard` | Dashboard analytics |
| GET | `/api/admin/monitoring` | Real-time monitoring |
| GET | `/api/admin/activity` | Activity feed |
| GET | `/api/admin/emergency-summary` | Emergency summary |

### Health
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |

## Standard Response Format

```json
{
  "success": true,
  "message": "Success message",
  "data": {},
  "errors": null
}
```

## AWS Deployment

1. Set `USE_IN_MEMORY_STORE=false`
2. Configure DynamoDB tables using `src/database/tableDefinitions.js`
3. Set AWS credentials and service ARNs in `.env`
4. Deploy Express via Lambda using `src/lambda.js` or containerize `src/server.js`

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start with Nodemon |
| `npm start` | Production start |
| `npm run lint` | ESLint |
| `npm run format` | Prettier |

## License

ISC

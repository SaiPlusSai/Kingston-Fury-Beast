const app = require('./app');
const { env } = require('./config/env');
const logger = require('./utils/logger');

const server = app.listen(env.port, () => {
  logger.info(`${env.appName} started`, {
    port: env.port,
    environment: env.nodeEnv,
    apiPrefix: env.apiPrefix,
    docs: `http://localhost:${env.port}/api-docs`,
  });
});

const gracefulShutdown = (signal) => {
  logger.info(`${signal} received, shutting down gracefully`);
  server.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

module.exports = server;

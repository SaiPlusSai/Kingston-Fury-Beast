const { SearchPlaceIndexForTextCommand } = require('@aws-sdk/client-location');
const { getLocationClient } = require('./clients');
const { env } = require('../config/env');
const logger = require('../utils/logger');

/**
 * Integración con Amazon Location Service.
 * Fallback a geocodificación local cuando el servicio no está configurado.
 */
class LocationService {
  constructor() {
    this.client = getLocationClient();
    this.placeIndex = env.location.placeIndex;
  }

  async searchPlaces(text, maxResults = 5) {
    if (!this.placeIndex) {
      logger.debug('Location place index not configured');
      return [];
    }

    try {
      const result = await this.client.send(
        new SearchPlaceIndexForTextCommand({
          IndexName: this.placeIndex,
          Text: text,
          MaxResults: maxResults,
        }),
      );
      return (result.Results || []).map((item) => ({
        label: item.Place?.Label,
        latitude: item.Place?.Geometry?.Point?.[1],
        longitude: item.Place?.Geometry?.Point?.[0],
      }));
    } catch (error) {
      logger.error('Location search failed', { error: error.message });
      return [];
    }
  }
}

module.exports = new LocationService();

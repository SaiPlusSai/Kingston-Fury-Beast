const { useInMemoryStore } = require('../database/dynamodb.client');
const dynamoDbService = require('../aws/dynamodb.service');

class BaseRepository {
  constructor(tableName, memoryStoreKey) {
    this.tableName = tableName;
    this.memoryStoreKey = memoryStoreKey;
    this.useMemory = useInMemoryStore;
  }

  getMemoryStore() {
    const { stores } = require('../database/inMemoryStore');
    return stores[this.memoryStoreKey];
  }

  async findById(idKey, idValue) {
    if (this.useMemory) {
      return this.getMemoryStore().get(idValue) || null;
    }
    return dynamoDbService.get(this.tableName, { [idKey]: idValue });
  }

  async save(item) {
    if (this.useMemory) {
      const key = item[Object.keys(item).find((k) => k.endsWith('Id'))];
      this.getMemoryStore().set(key, item);
      return item;
    }
    return dynamoDbService.put(this.tableName, item);
  }

  async remove(idKey, idValue) {
    if (this.useMemory) {
      this.getMemoryStore().delete(idValue);
      return;
    }
    return dynamoDbService.delete(this.tableName, { [idKey]: idValue });
  }

  async findAll() {
    if (this.useMemory) {
      return Array.from(this.getMemoryStore().values());
    }
    return dynamoDbService.scan(this.tableName);
  }
}

module.exports = BaseRepository;

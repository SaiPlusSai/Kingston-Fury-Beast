const BaseRepository = require('./base.repository');
const { tableNames } = require('../config/database');

class UserRepository extends BaseRepository {
  constructor() {
    super(tableNames.users, 'users');
  }

  async findById(userId) {
    return this.findByIdKey('userId', userId);
  }

  async findByIdKey(idKey, idValue) {
    if (this.useMemory) {
      return this.getMemoryStore().get(idValue) || null;
    }
    const dynamoDbService = require('../aws/dynamodb.service');
    return dynamoDbService.get(this.tableName, { [idKey]: idValue });
  }

  async findByEmail(email) {
    const normalizedEmail = email.toLowerCase();
    if (this.useMemory) {
      return Array.from(this.getMemoryStore().values()).find((u) => u.email === normalizedEmail) || null;
    }
    const items = await require('../aws/dynamodb.service').query(this.tableName, {
      IndexName: 'GSI_Email',
      KeyConditionExpression: 'email = :email',
      ExpressionAttributeValues: { ':email': normalizedEmail },
    });
    return items[0] || null;
  }

  async create(user) {
    return this.save(user);
  }

  async update(userId, updates) {
    const existing = await this.findById(userId);
    if (!existing) return null;
    const updated = { ...existing, ...updates, updatedAt: new Date().toISOString() };
    return this.save(updated);
  }
}

module.exports = new UserRepository();

const { sendSuccess } = require('../utils/apiResponse');
const { env } = require('../config/env');
const { useInMemoryStore } = require('../database/dynamodb.client');

const healthCheck = (req, res) => {
  sendSuccess(res, {
    message: 'UrbanShield API is healthy',
    data: {
      status: 'ok',
      environment: env.nodeEnv,
      timestamp: new Date().toISOString(),
      storage: useInMemoryStore ? 'in-memory' : 'dynamodb',
    },
  });
};

module.exports = { healthCheck };
